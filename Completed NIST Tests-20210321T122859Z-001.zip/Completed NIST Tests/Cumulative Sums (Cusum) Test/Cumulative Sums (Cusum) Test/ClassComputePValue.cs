﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cumulative_Sums__Cusum__Test
{
    class ClassComputePValue
    {
        public static double MethodComputePValue (int n , int z)
        {
            double result;
            double count = 0 , count1 = 0 , count2 = 0 , count3 = 0 , count4 =0 ;
            for(int  i = ((z-n) / z) / 4 ; i<= ((n - z) / z) / 4; i++)
            {
                count1 = count1 + ClassCDFCalculator.MethodCDFCalculator((4 * i + 1) * z / (Math.Sqrt(n)));
                count2 = count2 + ClassCDFCalculator.MethodCDFCalculator((4 * i - 1) * z / (Math.Sqrt(n)));
            }
            for (int i = ((-3*z - n) / z) / 4; i <= ((n - z) / z) / 4; i++)
            {
                count3 = count3 + ClassCDFCalculator.MethodCDFCalculator((4 * i + 3) * z / (Math.Sqrt(n)));
                count4 = count4 + ClassCDFCalculator.MethodCDFCalculator((4 * i + 1) * z / (Math.Sqrt(n)));
            }
            result = 1 - count1 + count2 + count3 - count4;
            Console.WriteLine("p-Value is     " + result);
            return result;
        }
    }
}
