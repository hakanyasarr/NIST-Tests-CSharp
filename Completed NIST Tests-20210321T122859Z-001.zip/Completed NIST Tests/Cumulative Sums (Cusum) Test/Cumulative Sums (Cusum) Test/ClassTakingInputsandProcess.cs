﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cumulative_Sums__Cusum__Test
{
    class ClassTakingInputsandProcess
    {
        public static void MethodTakingInputsandProcess()
        {
            string epsilonInput = "1011010111";         // input string
            int n = epsilonInput.Length;                                  // The length of the string
            int mode = 1;                                   // it decide the mode forwrd or backward
            List<int> sumList = new List<int>();                       // it will hold the consequtive sums
            int sum=0;                                       // it helps to record every sum to sumArray
            int i;  
            if(mode == 0)
            {
                for(i = 0 ; i<n ; i++ )
                {
                    if (epsilonInput[i] == '1')
                        sum = sum + 1;
                    else if (epsilonInput[i] == '0')
                        sum = sum - 1;
                    sumList.Add(sum);

                }
            }
            else if (mode == 1)
            {
                for (i = n-1; i >= 0 ; i--)
                {
                    if (epsilonInput[i] == '1')
                        sum = sum + 1;
                    else if (epsilonInput[i] == '0')
                        sum = sum - 1;
                    sumList.Add(sum);

                }
            }

            int maxValue;                   // these max and min represent the max and min value of the sumList
            int minValue;
            maxValue = sumList.Max();
            minValue = sumList.Min();
            int z = 0 ;                                  // it will hold the absolute max value in the list sumList
            if (Math.Abs(maxValue) < Math.Abs(minValue))
                z = Math.Abs(minValue);
            else if (Math.Abs(maxValue) > Math.Abs(minValue))
                z = Math.Abs(maxValue);
            double pValue = ClassComputePValue.MethodComputePValue(n, z);
            if(pValue >= 0.01 )
                Console.WriteLine("Since p-Value is bigger than 0.01  then process is random and p-Value is    "+pValue);
            if (pValue < 0.01)
                Console.WriteLine("Since p-Value is smaller than 0.01  then process is not random and p-Value is    " + pValue);


            return;
        }
    }
}
