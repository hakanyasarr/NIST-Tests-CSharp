﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Test
{
    // This class calculate 8 X^Obs 
    class ClassCalculateXSqrObs
    {
        public static void MethodCalculateXSqrObs(List<List<int>> stateFrequencyList , int J)
        {
            List<List<double>> piValueList = new List<List<double>>();
            for (int i = 0; i < 14; i++)
                piValueList.Add(new List<double>());
            piValueList[6].Add(0.5000);
            piValueList[6].Add(0.2500);
            piValueList[6].Add(0.1250);
            piValueList[6].Add(0.0625);
            piValueList[6].Add(0.0312);
            piValueList[6].Add(0.0312);

            piValueList[5].Add(0.7500);
            piValueList[5].Add(0.0625);
            piValueList[5].Add(0.0469);
            piValueList[5].Add(0.0352);
            piValueList[5].Add(0.0264);
            piValueList[5].Add(0.0791);

            piValueList[4].Add(0.8333);
            piValueList[4].Add(0.0278);
            piValueList[4].Add(0.0231);
            piValueList[4].Add(0.0193);
            piValueList[4].Add(0.0161);
            piValueList[4].Add(0.0804);

            piValueList[3].Add(0.8750);
            piValueList[3].Add(0.0156);
            piValueList[3].Add(0.0137);
            piValueList[3].Add(0.0120);
            piValueList[3].Add(0.0105);
            piValueList[3].Add(0.0733);

            piValueList[2].Add(0.9000);
            piValueList[2].Add(0.0100);
            piValueList[2].Add(0.0090);
            piValueList[2].Add(0.0081);
            piValueList[2].Add(0.0073);
            piValueList[2].Add(0.0656);

            piValueList[1].Add(0.9167);
            piValueList[1].Add(0.0069);
            piValueList[1].Add(0.0064);
            piValueList[1].Add(0.0058);
            piValueList[1].Add(0.0053);
            piValueList[1].Add(0.0588);

            piValueList[0].Add(0.9286);
            piValueList[0].Add(0.0051);
            piValueList[0].Add(0.0047);
            piValueList[0].Add(0.0044);
            piValueList[0].Add(0.0041);
            piValueList[0].Add(0.0531);


            piValueList[7].Add(0.5000);
            piValueList[7].Add(0.2500);
            piValueList[7].Add(0.1250);
            piValueList[7].Add(0.0625);
            piValueList[7].Add(0.0312);
            piValueList[7].Add(0.0312);

            piValueList[8].Add(0.7500);
            piValueList[8].Add(0.0625);
            piValueList[8].Add(0.0469);
            piValueList[8].Add(0.0352);
            piValueList[8].Add(0.0264);
            piValueList[8].Add(0.0791);

            piValueList[9].Add(0.8333);
            piValueList[9].Add(0.0278);
            piValueList[9].Add(0.0231);
            piValueList[9].Add(0.0193);
            piValueList[9].Add(0.0161);
            piValueList[9].Add(0.0804);
     
            piValueList[10].Add(0.8750);
            piValueList[10].Add(0.0156);
            piValueList[10].Add(0.0137);
            piValueList[10].Add(0.0120);
            piValueList[10].Add(0.0105);
            piValueList[10].Add(0.0733);

            piValueList[11].Add(0.9000);
            piValueList[11].Add(0.0100);
            piValueList[11].Add(0.0090);
            piValueList[11].Add(0.0081);
            piValueList[11].Add(0.0073);
            piValueList[11].Add(0.0656);

            piValueList[12].Add(0.9167);
            piValueList[12].Add(0.0069);
            piValueList[12].Add(0.0064);
            piValueList[12].Add(0.0058);
            piValueList[12].Add(0.0053);
            piValueList[12].Add(0.0588);

            piValueList[13].Add(0.9286);
            piValueList[13].Add(0.0051);
            piValueList[13].Add(0.0047);
            piValueList[13].Add(0.0044);
            piValueList[13].Add(0.0041);
            piValueList[13].Add(0.0531);


            List<double> xSqrList = new List<double>() ;              // This List will store p
            double xSqrValue;
            for(int a = 0 ; a < 8 ; a++)
            {
                xSqrValue = 0 ;
                for(int b = 0 ; b < 6; b++)
                {
                    xSqrValue = xSqrValue + (stateFrequencyList[a][b] - J * piValueList[a+3][b]) * (stateFrequencyList[a][b] - J * piValueList[a+3][b]) / (J * piValueList[a+3][b]);

                }
                xSqrList.Add(xSqrValue + 0 );
                
            }
            List<double> pValuesList = new List<double>();

            double pValue, pValue2;

            for(int d = 0 ; d<8 ; d++)
            {

                pValue = ClassIncompleteGamma.IncompleteGamma((double)5 / 2);

                pValue2 = ClassUpperIncompleteGama.incgamma((double)xSqrList[d] / 2, (double)5 / 2);

                pValue = (float)pValue2 / (float)pValue;
                pValue = 1 - pValue;
                pValuesList.Add(pValue);

            }

            for (int d = 0; d < 8; d++)
            {
                Console.WriteLine("  P - Value is    " + pValuesList[d]);
                if (pValuesList[d] >=  0.01)
                    Console.WriteLine(" siince above pValue is bigger than or equal to 0.01 then process is  random    " );
                else
                    Console.WriteLine(" siince above pValue is smaller than  0.01 then process is not random    ");
            }
                




            return;
        }
    }
}
