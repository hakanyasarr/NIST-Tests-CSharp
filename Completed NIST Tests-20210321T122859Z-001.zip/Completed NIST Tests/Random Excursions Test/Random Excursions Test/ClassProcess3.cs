﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Test
{
    class ClassProcess3
    {
        public static void MethodProcess3( List<List<int>> stateList, int J )
        {
            List<List<int>> stateFrequencyList = new List<List<int>>();

            for (int i = 0; i < 8; i++)
                stateFrequencyList.Add(new List<int>());
            List<int> generalList = new List<int>() ;               // This list will used for general purposes
            bool control;
            int count = 0;

            for (int k = 0 ; k<8 ; k++ )                            // This for loop and inside it creates table in part 6
            {
                generalList.Clear();
                for (int m = 0; m < stateList.Count; m++)
                    generalList.Add(stateList[m][k] + 0);
                for ( int a = 0 ; a <=5  ; a++ )
                {
                    for( ; ; )
                    {
                        control = generalList.Contains(a);
                        if (control == true)
                        {
                            count = count + 1;
                            generalList.RemoveAt(generalList.IndexOf(a));
                        }
                        else
                        {
                            stateFrequencyList[k].Add(count + 0);
                            count = 0;
                            break;
                        }

                    }
                  
                }

            }
            ClassCalculateXSqrObs.MethodCalculateXSqrObs(stateFrequencyList, J);

            return;
        }
    }
}
