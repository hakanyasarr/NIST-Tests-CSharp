﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Test
{
    class ClassUpperIncompleteGama
    {
        public static double incgamma(double x, double a)
        {
            double sum = 0;
            double term = 1.0 / a;
            int n = 1;
            while (term != 0)
            {
                sum = sum + term;
                term = term * (x / (a + n));
                n++;
            }
            return Math.Pow(x, a) * Math.Exp(-1 * x) * sum;
        }
    }
}
