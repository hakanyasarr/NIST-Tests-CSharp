﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Test
{
    // This class will continue process. This class consist of process after step 5
    class ClassProcess2
    {
        public static void MethodProcess2 (List<List<int>> cycleList , int J )
        {

            List<List<int>> stateList = new List<List<int>>();              //For each cycle and for each non-zero state value x having values –4 ≤ x ≤ -1 and 1 ≤ x ≤ 4,  compute the frequency of each x within each cycle.
            List<int> generalList = new List<int>();                    // This list will be used for general purposes
 
            for (int i = 0; i < cycleList.Count ; i++)                     // one for each cycle
                stateList.Add(new List<int>());
            bool control;                                       // Control value true or false
            int count = 0;
            for ( int k = 0 ; k<cycleList.Count ; k++)              // This for and inside them calculate state frequencies for each cyle and then record them  (it is step 5 of the test)
            {
                generalList.Clear();
                for(int m = 0 ; m<cycleList[k].Count ; m++ )
                {
                    generalList.Add( cycleList[k][m] + 0);
                }
                for(int p = -4 ; p <= 4 ; p++)
                {
                    for( ; ; )
                    {
                        if (p == 0)
                            break;
                        control = generalList.Contains(p);
                        if (control == true)
                        {
                            count = count + 1;
                            generalList.RemoveAt(generalList.IndexOf(p));
                        }
                        else
                        {          
                            stateList[k].Add(0 + count);
                            count = 0;                           
                            break;
                        }

                    }

                }

            }

            ClassProcess3.MethodProcess3(stateList , J);

            return;
        }
    }
}
