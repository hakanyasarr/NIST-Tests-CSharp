﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Test
{
    class ClassTakeInputs
    {
        public static void MethodTakeInputs()
        {
        
            string epsilonInput = "0110110101";         // input sequence that we want to test
            int n = epsilonInput.Length;                  //length of the input
            List<int> sumList = new List<int>();
            List<int> inputList = new List<int>();
            List<int> normalizedInputList = new List<int>();
            int sum = 0;
            for (int i = 0; i < n; i++)             // This for store elements of input in inputList
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input data. Input elements have to be 0 or 1");
                
            }
            for (int j = 0; j < n; j++)         // This for assign X values for every input element. For examle for element 1 store 1 and for element 0 store -1
            {
                if (inputList[j] == 1)
                    normalizedInputList.Add(1);
                else 
                    normalizedInputList.Add(-1);            
            }
            int count = 0;
            for(int k = 0 ; k < n ; k++)            //Compute the partial sums Si of successively larger subsequences, each starting with X1. For example sumList[2] = normalizedInputLİst[0]+normalizedInputLİst[1]+normalizedInputLİst[2]
            {
                count = count + normalizedInputList[k];
                sumList.Add(count + 0);
            }

          
            sumList.Add(0);                                 // at 0 beginin and end of the sumList
            sumList.Reverse();
            sumList.Add(0);
            sumList.Reverse();
            ClassProcess.MethodProcess(sumList, n);

            return;
        }
    }
}
