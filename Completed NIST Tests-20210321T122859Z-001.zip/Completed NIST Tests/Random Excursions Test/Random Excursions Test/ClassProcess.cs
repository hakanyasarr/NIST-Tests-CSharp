﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Test
{
    class ClassProcess
    {
        public static void MethodProcess(List<int> sumList , int n )
        {

            int J=-1 ;                      // J is the total number of zeros in the sumList except first zero sumList[0].   -1 means first zero is not a cycle
            List<List<int>> cycleList = new List<List<int>>();           // This List will store indexes of the zero crossing points
            List<int> indexZeroCrossingList = new List<int>();

            for (int i = 0; i < n+2; i++)            // This for calculate J (the number of cycles)
            {
                if (sumList[i] == 0)
                {
                    J = J + 1;
                    indexZeroCrossingList.Add(i);
                }                   
            }

            for (int k = 0; k < J; k++)                 // This for creates empty cycles for real cyles
                cycleList.Add(new List<int>());

            for ( int m = 0 ; m <J ; m++ )                  // this loop record all cycles to the cycleList
            {
                for( int p =indexZeroCrossingList[m] ; p <= indexZeroCrossingList[m+1] ; p++ )
                {
                    cycleList[m].Add(sumList[p]);
                }          
            }
                          
     
            ClassProcess2.MethodProcess2( cycleList , J ) ;


            return;
        }
    }
}
