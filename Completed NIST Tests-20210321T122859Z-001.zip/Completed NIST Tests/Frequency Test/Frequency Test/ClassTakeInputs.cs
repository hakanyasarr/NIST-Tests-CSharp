﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FrequencyTest
{
    class ClassTakeInputs
    {
        /*
        This class takes input string and determine and put every element of string in a list one by one
            */

        public static void MethodTakeInputs()
        {
            List<int> inputList = new List<int>();
            string epsilonInput = ("1011010101");               // The input sequence that we want to test for randomness
            int n = epsilonInput.Length ;                                        //input size
            for (int i = 0; i < n; i++)
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input !! input sequence elements must be collection of ones and zeros");
            }
            ClassProcess.MethodProcess(inputList, n);
            return;
        }
    }
}
         
            

/*

            float sObs;
            Random randomNumber = new Random();
            inputSize = randomNumber.Next(0, 1);

            for (int m = 0; m < 6; m++)               //it is which number of 1 that we want to give from outside
                inputList.Add(1);
            for (int n = 0; n < 4; n++)                 //it is which number of 0 that we want to give from outside
                inputList.Add(0);

            for (int i = 0; i < inputSize; i++)            // which number of input than have to be random then they will add to input list
            {
                inputList.Add(randomNumber.Next(0, 2));
            }
            for (int k = 0; k < inputList.Count; k++)       // writing inputList
                Console.Write(+inputList[k]);

            for( int j=0 ; j < inputList.Count ; j++)               //it calculates Sn
            {
                input = inputList[j];
                if (input == 1)
                    sInputSize = sInputSize + 1;
                else if (input == 0)
                    sInputSize = sInputSize - 1;
                else
                    Console.Write("Wrong Input Data !");
            }
            sObs = (float)Math.Abs(sInputSize) / (float)Math.Sqrt(inputList.Count);       //calculate Sobs
            Console.WriteLine("   \n total input number  "  +inputList.Count +"   Sn   "  + sInputSize +"   Sobs   " + sObs);
            
           
            double errorX;
            errorX = ClassErrorFunction.Erf((double)sObs / (double)Math.Sqrt(2));
            errorX = 1 - errorX;            // it converts erf fuction value to erfc function
           
            
            Console.WriteLine("P-Value     "+errorX);
            if(errorX >= 0.01)
            Console.WriteLine("Since P-Value is bigger than or equal to 0,01 then the process can accept random");
                else
            Console.WriteLine("Since P-Value is smaller than 0,01 then the process is not random");
            //  float pValue = 0 ;
            // pValue = System.Math.
            //  pValue = (float)Math. (sObs * Math.Sqrt(2));



            return;
        }

        private static double Erf()
        {
            throw new NotImplementedException();
        }
    }
}
*/