﻿//using NIST.FrequencyTest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequencyTest
{
    /*
        The focus of the test is the proportion of zeroes and ones for the entire sequence. The purpose of this test
is to determine whether the number of ones and zeros in a sequence are approximately the same as would
be expected for a truly random sequence. The test assesses the closeness of the fraction of ones to ½, that
is, the number of ones and zeroes in a sequence should be about the same. All subsequent tests depend on
the passing of this test. 

  input :  (1 input : string epsilonInput) input is a sequence (type is string and consist ones and zeros) that we want to test and see the sequence is random or not

  outbut : Output is P-Value(double type) that will help us to determine the sequence is random or not.
	       if the output (P-Value) is smaller than 0.01 then the sequence is not random. Otherwise sequence is random
    */

    class Program
    {
        static void Main()
        {
            ClassTakeInputs.MethodTakeInputs();

            return;
        }
    }
}
