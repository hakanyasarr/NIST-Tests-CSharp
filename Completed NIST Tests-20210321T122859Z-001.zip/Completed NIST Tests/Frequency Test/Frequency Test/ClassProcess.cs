﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequencyTest
{
    class ClassProcess
    {
        /*
            This class consist of the process of the test.
    */
        public static void MethodProcess (List<int> inputList , int n)
        {
            int sN = 0;                                 // (sN)it sums the difference between 1 and 0 . we will add 1 for the element 1 and we will add -1 for the element 0. For example, for the input string "101" Sn = +1 -1 +1 =1
            for(int i =0 ; i<n ; i++)                   // This for loop evaluat sN. 
            {
                if (inputList[i] == 1)
                    sN = sN + 1;
                else
                    sN = sN - 1;
            }

            double sObs = Math.Abs(sN) / Math.Sqrt(n) ;                    // it is test statistics Sobs = |Sn| / Sqrt(2)
            double pValue;                                                  // pValues is the output and that will help us to decide randomness
            pValue = ClassErrorFunction.Erf(sObs / Math.Sqrt(2));           // it calculates error function (erf) value
            pValue = 1 - pValue;                                            // Complement of erf (in other word erfc)
            Console.WriteLine("pValue is equal to    " + pValue);           // it writes to the screen P-Value
            if (pValue >= 0.01)                                                                         // This if else decide the sequence random or not according to the P-Value
                Console.WriteLine("pValue is bigger than 0.01 so input sequence is random     " );
            else
                Console.WriteLine("pValue is smaller than 0.01 so input is not random     ");

            return;
        }
    }
}
