﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIST.FrequencyTest
{
    public class Class1
    {
        public bool RunFrequencyTest(byte[] array, double threshold)
        {
            return true;
        }
    }
}
