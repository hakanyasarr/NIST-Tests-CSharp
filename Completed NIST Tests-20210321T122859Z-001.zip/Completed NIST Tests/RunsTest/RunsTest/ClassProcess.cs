﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RunsTest
{
    class ClassProcess
    {
        // This class is calculate P-Value. Then , P-Value will help us to decide the input sequence is random or not
        public static void MethodProcess(List<int> inputList,float preTestProportion, int n)
        {

            // Lets star with computing test statistics
            // Compute the test statistic V ( obs) = ∑r( k )+ 1 , where r(k)=0 if εk=εk+1, and r(k)=1 otherwise. 

            int vnObs;
            int numberofChanges = 0;                           //it will hold the number of changes between bits 
            for (int k = 0; k < inputList.Count - 1; k++)
            {
                if (inputList[k] != inputList[k + 1])
                    numberofChanges = numberofChanges + 1;
            }
            numberofChanges = numberofChanges + 1;                //numberof Ones is also a sum 
            vnObs = numberofChanges;                                // Now we evaluate test statistics (vnOns)

            // Let's start compute P-Value
            // P-value = erfc( | V (obs) − 2nπ (1−π ) | / 2 2nπ (1−π ) )
            double pValue;
            double pValue2;
            pValue = vnObs - 2 * n * preTestProportion * (1 - preTestProportion);
            pValue = Math.Abs(pValue);
            pValue2 = 2 * preTestProportion * (1 - preTestProportion) * Math.Sqrt(2 * n);
            pValue = pValue / pValue2;
            pValue = 1 - ClassErrorFunction.MethodErrorFunction(pValue);                                // actual P-Value is evaluated at this point

            Console.WriteLine("pValue is   " + pValue);
            if (pValue >= 0.01)
                Console.WriteLine("Since p-Value is bigger than or equal to  0.01 then the sequence is random");
            else
                Console.WriteLine("Since p-Value is smaller than 0.01 then the sequence is not random");
            
            return;
        }
    }
}
