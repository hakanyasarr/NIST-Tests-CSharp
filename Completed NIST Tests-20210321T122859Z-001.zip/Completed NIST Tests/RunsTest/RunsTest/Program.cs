﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RunsTest
{
    class Program
    {
        /*
        The focus of this test is the total number of runs in the sequence, where a run is an uninterrupted sequence
of identical bits. A run of length k consists of exactly k identical bits and is bounded before and after with
a bit of the opposite value.The purpose of the runs test is to determine whether the number of runs of
2-5 A STATISTICAL TEST SUITE FOR RANDOM AND PSEUDORANDOM NUMBER GENERATORS FOR CRYPTOGRAPHIC APPLICATIONS
ones and zeros of various lengths is as expected for a random sequence.In particular, this test determines
whether the oscillation between such zeros and ones is too fast or too slow.
        
        input : In this test , there is one input (epsilonInput). epsilon input is the sequence ( consist of ones and zeros ) that we want to test for randomness

        output : Output is P-Values. P-Values will help us to decide the sequence is random or not.
                  if P-Value is smaller tha 0.01 , then the sequence is not random. Otherwise the sequence is random.
*/

        static void Main( )
        {

            ClassTakeInputs.MethodTakeInputs();
            return;
        }
    }
}
