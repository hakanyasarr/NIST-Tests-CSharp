﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RunsTest
{
    class ClassTakeInputs
    {
        // This class take input (strng type )(epsilon input) and record the element of the epsilonInput to the inputList (int type)
        // This class also evaluate some necessary parameters like tao
        // Finally decide this test is applicable or not for this sequence. If not applicable, the return to the main function without any action
        public static void MethodTakeInputs()
        {
            string epsilonInput = ("1100100100001111110110101010001000100001011010001100001000110100110001001100011001100010100010111000");                   // The input sequence (epsilonInput) (string type) that we want to test for randomness

            int n = epsilonInput.Length ;                         // the number of elements in input (epsilonInput). In other words, input size
            float tao = 2 / (float)Math.Sqrt(n);                    // tao = 2 / Sqrt (n)  . tao will help us to decide continue to the test or not
       
            List<int> inputList = new List<int>();              // This list will hold the elements of the epsilonInput as integers (as 1 or 0 )
            for (int i = 0; i < n; i++)                         // This for record the elements in epsilonInput to the inputList
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input data, input member can be zero or one");
            }

            float preTestProportion;                                // it is the intensity of ones in input sequence
            int numberofOnes =0 ;                                    // it will hold the total number of ones in sequence
            for (int j = 0; j < inputList.Count; j++)                // This for is calculating the total number of ones (record it to the numberofOnes to evaluate Pre Test Proportion
            {
                if (inputList[j] == 1)
                    numberofOnes = numberofOnes + 1;
            }

            preTestProportion = (float)numberofOnes / (float)n;     // This equation calculate Pre Test Proportion    
            
            // Now we will calculate  | preTestProportion -(1/2)|     

            double preTestProportion2 = preTestProportion - 0.5 ;
   
            if (preTestProportion2 < 0)
                preTestProportion2 = preTestProportion2 * (-1);

            if (preTestProportion2 >= tao )                         // is is decideing unit that decide the test is necessary or not for the input sequence
            {
                double pValue;
                pValue = 0;
                Console.WriteLine("Runs test need not be performed and pValue is     " +pValue);
                return;
            }
            ClassProcess.MethodProcess(inputList, preTestProportion, n);
            return;
            }
        }
}
