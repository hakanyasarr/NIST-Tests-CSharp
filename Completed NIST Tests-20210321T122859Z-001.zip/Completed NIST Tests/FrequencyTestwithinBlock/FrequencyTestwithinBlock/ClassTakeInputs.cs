﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequencyTestwithinBlock
{
    // This class takes inputs 
    class ClassTakeInputs
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="epsilonInput">input sequence (input sequence must be collection of ones and zeros) that we want to test</param>
        /// <param name="M">input length of the each block. This means every block have M number of element</param>
        public static void MethodTakeInputs(string epsilonInput, int M)
        {

            //string epsilonInput = ("0110011010");                       // input sequence (input sequence must be collection of ones and zeros) that we want to test
            //int M = 3;                                                  // input length of the each block. This means every block have M number of element

            int n = epsilonInput.Length;                                 // input size. n shows us the total element number of input sequence
            int N = (n / M);                                            //the total block number in our sequence. 

            List<int> inputList = new List<int>();              // this list will hold the elements of epsilonInput as integers

            for (int i = 0; i < n; i++)                         // This for loop transfer the elemens in epsilonInput to the inputList
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input data, input member can be zero or one");
            }
            ClassProcess.MethodProcess(inputList, n, N, M);


            return;
        }

    }
}
