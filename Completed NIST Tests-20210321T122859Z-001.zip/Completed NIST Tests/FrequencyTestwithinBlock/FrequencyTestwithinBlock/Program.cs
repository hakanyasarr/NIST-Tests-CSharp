﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequencyTestwithinBlock
{
    class Program
    {
        
        /*
    The focus of the test is the proportion of ones within M-bit blocks. The purpose of this test is to determine
whether the frequency of ones in an M-bit block is approximately M/2, as would be expected under an
assumption of randomness. For block size M=1, this test degenerates to test 1, the Frequency (Monobit)
test. 
    input  : In this test we have 2 inputs. 
             One of them epsilonInput (string type) that is the sequence (consist of ones and zeros) we want to test (it is random sequence or not)
             The other input is M ( int type ). M represent the length of each block. As we understood , in this test we will divide our input sequence into blocks

    output : The output is P-Value that help us to determine input sequence is random or not.
             If P-Value is smaller than 0.01 , the the sequence is not random. Otherwise the sequence is random.

*/
        static void Main()
        {

            ClassTakeInputs.MethodTakeInputs("01011101010", 3);

            return;        
        }
    }
}
