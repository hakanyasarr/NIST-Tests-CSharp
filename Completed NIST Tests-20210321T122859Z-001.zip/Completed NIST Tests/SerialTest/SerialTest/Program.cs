﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerialTest
{
    class Program
    {
        static void Main()
        {
            /*
            The focus of this test is the frequency of all possible overlapping m-bit patterns across the entire
sequence. The purpose of this test is to determine whether the number of occurrences of the 2m m-bit
overlapping patterns is approximately the same as would be expected for a random sequence. Random
sequences have uniformity; that is, every m-bit pattern has the same chance of appearing as every other
m-bit pattern. Note that for m = 1, the Serial test is equivalent to the Frequency test of Section 2.1. 

            input : input sequence ( string type ) ( epsilonInput ) that we want to test
                    input m (int type). The length in bits of the bit string. 

            output : 2 output 2 P-Values that will help us to decide the sequence is random or not
    */
            ClassTakeInputs.MethodTakeInputs();
            return;
        }
    }
}
