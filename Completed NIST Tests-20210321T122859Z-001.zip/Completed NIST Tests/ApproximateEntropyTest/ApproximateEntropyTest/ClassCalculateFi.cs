﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApproximateEntropyTest
{
    class ClassCalculateFi
    {
        public static double MethodCalculateFi(List<float> frequencyIntensityList)
        {
            double fiValue = 0;

            for (int i = 0 ; i < frequencyIntensityList.Count ; i++ )
            {
                if (frequencyIntensityList[i] != 0)
                {
                    fiValue = fiValue + frequencyIntensityList[i] * Math.Log(frequencyIntensityList[i]);
                }
                else
                    fiValue = fiValue + 0;
            
            }
            return fiValue;
        }
    }
}
