﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApproximateEntropyTest
{
    class Program
    {
        /*
        As with the Serial test of Section 2.11, the focus of this test is the frequency of all possible overlapping
m-bit patterns across the entire sequence. The purpose of the test is to compare the frequency of
overlapping blocks of two consecutive/adjacent lengths (m and m+1) against the expected result for a
random sequence. 

            input : input sequence (string type)(epsilonInput) that we want to test
                    input m (int type) . The length of each block – in this case, the first block length used in the test. m+1 is the
                        second block length used. 

            output : P-Value that will help us to decide the sequence is random or not

    */
        static void Main()
        {

            ClassTakeInputs.MethodTakeInputs();
            return;
        }
    }
}
