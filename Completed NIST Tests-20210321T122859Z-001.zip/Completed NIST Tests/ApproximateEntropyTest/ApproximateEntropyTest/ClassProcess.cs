﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApproximateEntropyTest
{
    class ClassProcess
    {
        public static void MethodProcess(List<int> inputList, int m, int n)
        {
            List<float> frequencyIntensityList = new List<float>();                 // This list will record Ci Values
            frequencyIntensityList = ClassFrequencyCalculator.MethodFrequencyCalculator(inputList, m, n);
            double fiValue;
            fiValue = ClassCalculateFi.MethodCalculateFi(frequencyIntensityList);

            // Now repeat process but put m+1 instead of m

            inputList.Add(inputList[m - 1]);
            List<float> frequencyIntensityList2 = new List<float>();
            frequencyIntensityList2 = ClassFrequencyCalculator.MethodFrequencyCalculator(inputList, m+1 , n);
            double fiValue2;
            fiValue2 = ClassCalculateFi.MethodCalculateFi(frequencyIntensityList2);


            double apEnM = fiValue - fiValue2 ;
            double xSqr = 2 * n * (Math.Log(2) - apEnM);

            double gammaValue, gammaValue2 ;
            double gammaInput = Math.Pow(2, (double)m - 1);
         
            double gammaInput2 = xSqr / 2;
            gammaValue = ClassGama.IncompleteGamma(gammaInput);

            gammaValue2 = ClassIncompleteGama.incgamma(gammaInput2, gammaInput);
 
            gammaValue = (float)gammaValue2 / (float)gammaValue;
            gammaValue = 1 - gammaValue;

            Console.WriteLine("P-Value is equal to " + gammaValue);
            if (gammaValue < 0.01)
                Console.WriteLine("Since P-Value is smaller than 0.01 then the input sequence is not random ");
            else
                Console.WriteLine("Since P-Value is bigger than or equal to 0.01 then the input sequence is random ");






            return;
        }
    }
}
