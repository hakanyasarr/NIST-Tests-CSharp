﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApproximateEntropyTest
{
    class ClassFrequencyCalculator
    {
        public static List<float> MethodFrequencyCalculator(List<int> inputList, int m, int n)
        {
            List<int> inputList2 = new List<int>();
            List<int> frequencyList = new List<int>();
            List<float> frequencyIntensityList = new List<float>();
            int count;

            for (int i = 0; i < inputList.Count; i++)
                inputList2.Add(inputList[i]);
            int maxValue = (int)Math.Pow(2, m) - 1;                               // it will store  max value of the m bit binary number


            int value;                              // any m bit value in input list
            for (int x = 0; x <= maxValue; x++)
            {
                count = 0;
                for (int k = 0; k <= inputList.Count - m; k++)
                {
                    value = 0;
                    for (int a = 0; a < m; a++)
                    {
                        value = value + (int)Math.Pow(2, m - 1 - a) * inputList2[k + a];
                    }
                    if (value == x)
                        count = count + 1;
                }
                frequencyList.Add(count + 0);
            }
            // Now frequencyList hold all frequencies , let start to find  C = frequency / n

            for( int b = 0 ; b<frequencyList.Count ; b++)
            {
                frequencyIntensityList.Add((float)frequencyList[b] / (float)n);
            }


            return frequencyIntensityList;
        }
    }
}
