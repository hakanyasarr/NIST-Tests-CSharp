﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApproximateEntropyTest
{
    class ClassTakeInputs
    {
        public static void MethodTakeInputs()
        {

            string epsilonInput = "0100110101";
            int m = 3;
            int n = epsilonInput.Length;

            List<int> inputList = new List<int>();

            for (int i = 0; i < n; i++)
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input data. Input sequence have to be collection of 1 and 0");
            }

            for (int j = 0; j < m - 1; j++)
            {
                inputList.Add(inputList[j]);
            }


            ClassProcess.MethodProcess(inputList, m, n);
            return;
        }
    }
}
