﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestStatisticRefDistribu
{
    class ClassTakeInput
    {
        public static void MethodTakeInput()
        {
            string epsilonInput = "10100100101110010110";                                   // input sequence that we want to test
            int n = epsilonInput.Length;                                                                 //  input sequence length (epsilonInut length)
            string B = "001";                                                          // it is the template that we will search in the blocks of epsilonInput string
            int m = B.Length;                        // The size of the template string

            int M = 10 ;                            // The size of the each  block
            int N = n / M ;                              //The number of the total block

            List<int> inputList = new List<int>();                      // This for loop help us record epsilonInput elements into a List
            for( int i = 0 ; i<n ; i++ )
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine(" Wrong input !! input string must be collection of the ones and zeros");                
            }
            List<int> bList = new List<int>();              
            for( int j = 0 ; j < m  ; j++)                       // This for loop help us record string B elements into a List
            {
                if (B[j] == '1')
                    bList.Add(1);
                else if (B[j] == '0')
                    bList.Add(0);
                else
                    Console.WriteLine("Wrong input !! Template have to be a collection of ones and zeros");
            }         

            int decimalValueB = 0 ;
            for(int k = 0 ; k < m ; k++ )                       // it calculates the decimal value of binary number template
            {
                decimalValueB = decimalValueB + (int)Math.Pow(2, m - 1 - k) * bList[k] ;
            }

            ClassProcess.MethodProcess(inputList,decimalValueB,N,M,m);




            

            return;
        }
    }
}
