﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestStatisticRefDistribu
{
    /*
    The focus of this test is the number of occurrences of pre-specified target strings. The purpose of this
test is to detect generators that produce too many occurrences of a given non-periodic (aperiodic) pattern.
For this test and for the Overlapping Template Matching test of Section 2.8, an m-bit window is used to
search for a specific m-bit pattern. If the pattern is not found, the window slides one bit position. If the
pattern is found, the window is reset to the bit after the found pattern, and the search resumes. 

        input : (2 inputs). One of them is input sequence (epsilonInput)(sring type) that we want to test
                The other input is M (int type). The number of elemets that each block must have

        output : P-Value (double). it help us to decide the sequence is random or not.
    */
    class Program
    {
        static void Main()
        {
            ClassTakeInput.MethodTakeInput();
            return;
        }
    }
}
