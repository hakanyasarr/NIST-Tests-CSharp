﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestStatisticRefDistribu
{
    class ClassProcess
    {
        public static void MethodProcess(List<int> inputList, int decimalValueB, int N , int M , int m)
        {
            List<int> wList = new List<int>() ;                             // it will store the number of the template in each block
            int count ;
            int values;
            for(int i = 0 ; i<N ; i++ )
            {
                count = 0;
                for( int j = 0 ; j<M-m+1 ; j++ )
                {
                    values = 0;
                    for( int k = 0 ; k < m ; k++ )
                    {
                        values = values + (int)Math.Pow(2, m - 1 - k) * inputList[i * M + j + k];
                    }
                    if (values == decimalValueB)
                    {
                        count = count + 1;
                        j = j + m - 1;
                    }
                 
                }
                wList.Add(count);
            }
            double mean, variance;                  // Theorical mean and variances
            mean = (M - m + 1) / Math.Pow(2, (double)m);
            variance = (1 / Math.Pow(2, (double)m)) - ((2 * m - 1) / Math.Pow(2, (double)2 * m));           // two steps for calculating variance
            variance = variance * M;


            // Let calculte X^2 Obs

            double xSqrObs=0;
            for(int a = 0 ; a < N ; a++)
            {
                xSqrObs = xSqrObs + (wList[a] - mean) * (wList[a] - mean);
            }

            xSqrObs = xSqrObs / variance ;


            // Let's start to calculate P-Value from gamma functions
            double pValue, pValue2; ;

            pValue = ClassGamma.Gamma((double)N / 2);
            pValue2 = ClassLowerGamma.incgamma((double)N / 2, (double)xSqrObs / 2);

            pValue = (float)pValue2 / (float)pValue;                            // it is lower incomplete gamma value but we need upper incomplete gamma value.So take complement
            pValue = 1 - pValue;                            // now we calculated P-Value



            Console.WriteLine("P-Value is equal to   " + pValue);

            if (pValue >= 0.01)
            {
                Console.WriteLine("Since pValue is bigger than or equal to 0.01 , then the process is random");
            }
            else
                Console.WriteLine("Since pValue is smaller than 0.01 , then the process is not random");





            return;
        }
    }
}
