﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinearComplexityTest
{
    class Program
    {
        /*
             The focus of this test is the length of a linear feedback shift register (LFSR). The purpose of this test is to
        determine whether or not the sequence is complex enough to be considered random. Random sequences
        are characterized by longer LFSRs. An LFSR that is too short implies non-randomness. 

            input : input sequence (string type ) epsilonInput that we want to test
                    M (int type) that the number of elements each block should have

            output : P-Value (duble type) that will help us to decide the input sequence is random or not

        */
        
        static void Main()
        {
            List<int> BD = new List<int>();

            ClassTakingInputs.MethodTakingInputs();


            return;
        }
    }
}
