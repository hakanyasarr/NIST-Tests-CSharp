﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinearComplexityTest
{
    class ClassProcess
    {
        public static void MethodProcess(List<int> inputList, int N , int M , int K)
        {
            List<int> linearComplexityListL = new List<int>();                  // it will hold linear complexities of every block
            List<int> inputListofEachBlock = new List<int>();                   // This list will hold elements of a block to calculate Linear Complexity of that block
            int linearComplexityValueL;                                         // Linear compelxities output for each block
            for (int i = 0 ; i < N; i++)
            {
                inputListofEachBlock.Clear();
                for(int j = 0 ; j < M ; j++)
                {
                    inputListofEachBlock.Add(inputList[i*M + j] );
                }            
                linearComplexityValueL = ClassBerlekampMasseyAlgorithm.MethodBerlekampMasseyAlgorithm(inputListofEachBlock);
                linearComplexityListL.Add(linearComplexityValueL);
            }

            // Now, we have to calculate mean
            double meanU;
            int signM;                       // The sign value will help us to calculate mean by decide (-1)^M+1 is one or minus one
            signM = M - (M / 2) * 2;         // if M is odd then sig is 1 , otherwise 0
            if (signM == 1)
                signM = 1;
            else
                signM = -1;
            int expTwo = 1;                     // this will help us to calculate 2^M in formula
            for (int k = 0; k < M; k++)
                expTwo = expTwo * 2;

            meanU = ((double)M / 2) + ((double)(9 + signM) / 36) - ((double)(3 * M + 2) / (9 * expTwo));
    
            // Now Calculate T values
            List<double> tValuesList = new List<double>() ;
            signM = signM * (-1) ;
            for (int a = 0 ; a < N ; a++ )
            {
                tValuesList.Add(signM * (linearComplexityListL[a] - meanU) + ((double)2 / 9));
            }

            // Change   linearComplexityList according  to the vlues of T[]

            for(int a = 0 ; a < N ; a++ )
            {
                if (tValuesList[a] <= (-2.5))
                {
                    linearComplexityValueL = linearComplexityListL[0];
                    linearComplexityListL.RemoveAt(0);
                    linearComplexityListL.Insert(0, linearComplexityValueL + 1);
                }
               else if ((tValuesList[a] <= (-1.5))  && (tValuesList[a] > (-2.5)))
                {
                    linearComplexityValueL = linearComplexityListL[1];
                    linearComplexityListL.RemoveAt(1);
                    linearComplexityListL.Insert(1, linearComplexityValueL + 1);
                }
                else if ((tValuesList[a] <= (-0.5)) && (tValuesList[a] > (-1.5)))
                {
                    linearComplexityValueL = linearComplexityListL[2];
                    linearComplexityListL.RemoveAt(2);
                    linearComplexityListL.Insert(2, linearComplexityValueL + 1);
                }
                else if ((tValuesList[a] <= (0.5)) && (tValuesList[a] > (-0.5)))
                {
                    linearComplexityValueL = linearComplexityListL[3];
                    linearComplexityListL.RemoveAt(3);
                    linearComplexityListL.Insert(3, linearComplexityValueL + 1);
                }
                else if ((tValuesList[a] <= (1.5)) && (tValuesList[a] > (0.5)))
                {
                    linearComplexityValueL = linearComplexityListL[4];
                    linearComplexityListL.RemoveAt(4);
                    linearComplexityListL.Insert(4, linearComplexityValueL + 1);
                }
                else if ((tValuesList[a] <= (2.5)) && (tValuesList[a] > (1.5)))
                {
                    linearComplexityValueL = linearComplexityListL[5];
                    linearComplexityListL.RemoveAt(5);
                    linearComplexityListL.Insert(5, linearComplexityValueL + 1);
                }
                else if (tValuesList[a] > (2.5))
                {
                    linearComplexityValueL = linearComplexityListL[6];
                    linearComplexityListL.RemoveAt(6);
                    linearComplexityListL.Insert(6, linearComplexityValueL + 1);
                }
            }

            // Now compute X^Obs
            List<double> preproportionalList = new List<double>();
            preproportionalList.Add(0.010417);
            preproportionalList.Add(0.03125);
            preproportionalList.Add(0.125);
            preproportionalList.Add(0.5);
            preproportionalList.Add(0.25);
            preproportionalList.Add(0.0625);
            preproportionalList.Add(0.020833);

            double xSqrObs = 0;
            for( int b = 0 ; b <= K ; b++ )
            {
                xSqrObs = xSqrObs + (linearComplexityListL[b] - (double)N * preproportionalList[b]) * (linearComplexityListL[b] - (double)N * preproportionalList[b]) / ((double)N * preproportionalList[b]);
            }


            double pValue, pValue2;

            pValue = ClassGamma.Gamma((double)K / 2);
            pValue2 = ClassLowerGamma.incgamma((double)K / 2, (double)xSqrObs / 2);

            pValue = (float)pValue2 / (float)pValue;                            // it is lower incomplete gamma value but we need upper incomplete gamma value.So take complement
            pValue = 1 - pValue;                            // now we calculated P-Value



            Console.WriteLine("P-Value is equal to   " + pValue);

            if (pValue >= 0.01)
            {
                Console.WriteLine("Since pValue is bigger than or equal to 0.01 , then the process is random");
            }
            else
                Console.WriteLine("Since pValue is smaller than 0.01 , then the process is not random");




            return;
        }
    }
}
