﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinearComplexityTest
{
    class ClassBerlekampMasseyAlgorithm
    {
        /*        
            This class help us to calculate Linear Complexity of a sequence.
            This sequence is a binary sequence.
            The return value is  Linear complexity value of sequence
        */
        public static int MethodBerlekampMasseyAlgorithm(List<int> inputListofEachBlock)
        {
            int n = inputListofEachBlock.Count();
            int L =0, m = -1 , d  ;                                          
            List<int> CD = new List<int>();                     // These are tree polnomial that have variables D.   C(D) = 1 + c(1)D(1) + c(2)D(2) + ...
            CD.Add(1);
            List<int> BD = new List<int>();
            BD.Add(1);
            List<int> iterationBD = new List<int>();
            
            List<int> TD = new List<int>();
            int element=0;                                    // it will used any purpose when it is necessary

            for ( int N =0 ; N<n ; N++ )
            {
                d = 0 ;   
                for(int i =1 ; i <= L ; i++ )                               // This for loop calculate a part of discrepancy
                {                    
                    if ( i < CD.Count)
                    {
                        if (N >= i)
                        {
                            element = CD[i] + 0;
                            element = inputListofEachBlock[N - i] * element;
                        }
                        else
                            d = d + 0;
          
                    }
                    else                    
                        element = 0;
                        
                    d = d + element;
                }
                d = inputListofEachBlock[N] + d;
                d = d - (d / 2) * 2 ;                           // This help us to calculate mod2 value of d
                if (d == 1)
                {
                    TD.Clear();
                    for (int j = 0; j < CD.Count; j++)            // This for loop calculate T(D) = C(D)
                    {
                        TD.Add(CD[j] + 0);
                    }
                    iterationBD.Clear();
                    for (int k = 0; k < (N - m); k++)             // This for calculate B(D)*D^(N--m)
                    {                       
                        iterationBD.Add(0);  
                    }
                    for (int x = 0; x < BD.Count; x++)
                        iterationBD.Add(BD[x]+0);
                    for (int l = 0; l < iterationBD.Count; l++)                 // // This for calculate C(D) = C(D) + B(D)*D^(N--m)
                    {
                        if (l < CD.Count)
                        {
                            element = CD[l]+0;
                            CD.RemoveAt(l);
                            CD.Insert(l, element + iterationBD[l]);
                            element = 0;
                        }
                        else
                        {
                            element = 0;
                            CD.Insert(l, element + iterationBD[l]);
                        }
                    }



                    if (L <= (N / 2))
                    {
                        L = N + 1 - L;
                        m = N;
                        BD.Clear();
                        for (int z = 0; z < TD.Count; z++)
                        {
                            BD.Add(TD[z]+0);
                        }
                    }

                }
                
            }

     


            return L;
        }
    }
}
