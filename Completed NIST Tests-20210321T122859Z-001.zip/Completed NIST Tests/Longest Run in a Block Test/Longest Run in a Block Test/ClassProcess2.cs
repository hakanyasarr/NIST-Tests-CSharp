﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Longest_Run_in_a_Block_Test
{

    // This class help us to calculate the frequencies of the max frequency ones of blocks
    class ClassProcess2
    {
        public static List<int> MethodProcess2(List<int> maxFrequencyList, int M, List<int> countList)
        {

            List<int> frequencyList = new List<int>();
            int count = 0;                          // the count will try to detect the mximum number of one (consecutive ones) for each block
            int range;

            int minFrequency = maxFrequencyList.Min();          // these max min values help us to bound maxFrequencyList to calculate frequencies. Actually , they are min and max values in maxFrequencyList
            int maxFrequency = maxFrequencyList.Max();

            for (int a = minFrequency; a <= maxFrequency; a++)          // Find all frequencies of maxFrequencyList. This for loop calculate the frequencies of elements in the maxFrequencyList and then record them to the frequencyList
            {
                for (;;)
                {
                    bool control = maxFrequencyList.Remove(a);
                    if (control == true)
                        count = count + 1;
                    else
                        break;
                }

                frequencyList.Add(count + 0);
                count = 0;
            }


            for (int z = minFrequency; z <= maxFrequency; z++)              // sorted elements from minFrequency to maxFrequency. 
                countList.Add(z);

            //Now we have elements at countList and their corresponding frequencies at frequencyList

  
            int element = 0;
            if (M == 8)
            {
                range = minFrequency - 1;
                for (; range > 0; range--)
                {
                    frequencyList.Reverse();
                    frequencyList.Add(0);
                    frequencyList.Reverse();
                    countList.Reverse();
                    countList.Add(range);
                    countList.Reverse();
                }
                range = 4 - maxFrequency;
                for (; range > 0; range--)
                {
                    frequencyList.Add(0);
                    countList.Add(5 - range);
                }

                for (;;)
                {
                    if (countList[0] <= 1)
                    {
                        element = frequencyList[0] + element;
                        frequencyList.RemoveAt(0);
                        countList.RemoveAt(0);
                    }

                    else
                        break;

                }
                frequencyList.Reverse();
                frequencyList.Add(element + 0);
                frequencyList.Reverse();
                countList.Reverse();
                countList.Add(1);
                countList.Reverse();

                element = 0;
                int index = 0;
                index = countList.Count - 1;
                for (; ; index--)
                {
                    if (index < 0)
                        break;
                    if (countList[index] >= 4)
                    {
                        element = element + frequencyList[index];
                        countList.RemoveAt(index);
                        frequencyList.RemoveAt(index);
                    }
                    else
                        break;

                }
                frequencyList.Add(element + 0);
                countList.Add(4);

            }






            if (M == 128)
            {
                range = minFrequency - 4;
                for (; range > 0; range--)
                {
                    frequencyList.Reverse();
                    frequencyList.Add(0);
                    frequencyList.Reverse();
                    countList.Reverse();
                    countList.Add(range + 3);
                    countList.Reverse();
                }
                range = 9 - maxFrequency;
                for (; range > 0; range--)
                {
                    frequencyList.Add(0);
                    countList.Add(10 - range);
                }


                for (;;)
                {
                    if (countList[0] <= 4)
                    {
                        element = frequencyList[0] + element;
                        frequencyList.RemoveAt(0);
                        countList.RemoveAt(0);
                    }

                    else
                        break;

                }
                frequencyList.Reverse();
                frequencyList.Add(element + 0);
                frequencyList.Reverse();
                countList.Reverse();
                countList.Add(4);
                countList.Reverse();

                element = 0;
                int index = 0;
                index = countList.Count - 1;
                for (; ; index--)
                {
                    if (index < 0)
                        break;
                    if (countList[index] >= 9)
                    {
                        element = element + frequencyList[index];
                        countList.RemoveAt(index);
                        frequencyList.RemoveAt(index);
                    }
                    else
                        break;

                }
                frequencyList.Add(element + 0);
                countList.Add(9);

            }






            if (M == 10000)
            {
                range = minFrequency - 10;
                for (; range > 0; range--)
                {
                    frequencyList.Reverse();
                    frequencyList.Add(0);
                    frequencyList.Reverse();
                    countList.Reverse();
                    countList.Add(range + 9);
                    countList.Reverse();
                }
                range = 16 - maxFrequency;
                for (; range > 0; range--)
                {
                    frequencyList.Add(0);
                    countList.Add(17 - range);
                }

                for (;;)
                {
                    if (countList[0] <= 10)
                    {
                        element = frequencyList[0] + element;
                        frequencyList.RemoveAt(0);
                        countList.RemoveAt(0);
                    }

                    else
                        break;

                }
                frequencyList.Reverse();
                frequencyList.Add(element + 0);
                frequencyList.Reverse();
                countList.Reverse();
                countList.Add(10);
                countList.Reverse();

                element = 0;
                int index = 0;
                index = countList.Count - 1;
                for (; ; index--)
                {
                    if (index < 0)
                        break;
                    if (countList[index] >= 16)
                    {
                        element = element + frequencyList[index];
                        countList.RemoveAt(index);
                        frequencyList.RemoveAt(index);
                    }
                    else
                        break;

                }
                frequencyList.Add(element + 0);
                countList.Add(16);

            }


            return frequencyList;
        }
    }
}
