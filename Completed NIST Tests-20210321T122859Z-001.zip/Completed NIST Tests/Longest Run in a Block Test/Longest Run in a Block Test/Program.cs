﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Longest_Run_in_a_Block_Test
{
    /*
    The focus of the test is the longest run of ones within M-bit blocks. The purpose of this test is to
determine whether the length of the longest run of ones within the tested sequence is consistent with the
length of the longest run of ones that would be expected in a random sequence. Note that an irregularity in
the expected length of the longest run of ones implies that there is also an irregularity in the expected
length of the longest run of zeroes. 

        input : In this test, there is 1 input (epsilonInput) (type string) that we want to test for randomness. epsilonInput is a sequence that is consist ones and zeros.

        output : Output is P-Value. P-Value help us to determine the sequence is random or not.
                if P-Value is smaller than 0.01 , then the input sequence is not random. Otherwise, the sequence is random
     */
    class Program
    {
        static void Main()
        {
            ClassTakeandProcessInput.MethodTakeandProcessInput();
            return;
        }
    }
}
