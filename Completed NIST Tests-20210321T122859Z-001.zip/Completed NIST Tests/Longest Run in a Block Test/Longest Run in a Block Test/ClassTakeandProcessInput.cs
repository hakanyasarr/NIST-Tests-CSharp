﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Longest_Run_in_a_Block_Test
{
    public class ClassTakeandProcessInput
    {
        public static void MethodTakeandProcessInput()
        {


            string epsilonInput = ("11001100000101010110110001001100111000000000001001001101010100010001001111010110100000001101011111001100111001101101100010110010");                          // input sequence epsilonInput (string type)

            int n = epsilonInput.Length;                                  // it is the input size. In other words, the total elements number in input sequence. The minimum must be 128

            int M;                                                    // The lengt of each block. The value of M will assign automotically depennd  on n(input size)
            if ((128 <= n) && (n < 6272))                               // This if else s determine the value of M based on value of n
                M = 8;
            else if ((6272 <= n) && (n < 750000))
                M = 128;
            else if (750000 <= n)
                M = 10000;
            else
            {
                Console.WriteLine("Wrong input !! The length of the input consist of minimum from 128 elementss");
                return;
            }

            List<int> inputList = new List<int>();          // This for loop transfer the elements of input sequence (epsilonInput) to the inputList as integer
            for (int i = 0; i < n; i++)
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Unexpected input data input sequence have to be collection of one and zero");
            }

            int N = n / M;                                                            // The block number of the input sequence
            ClassProcess.MethodProcess(inputList, N, M);

            return;
        }
    }
}
