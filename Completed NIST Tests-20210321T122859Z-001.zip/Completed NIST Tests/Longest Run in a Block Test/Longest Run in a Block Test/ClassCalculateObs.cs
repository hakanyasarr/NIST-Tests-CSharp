﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Longest_Run_in_a_Block_Test
{
    // This class will help us to calculate Obs value for the test
    class ClassCalculateObs
    {
        public static double MethodCalculateObs(List<int> frequencyList, int N, int M)
        {
            List<double> piList = new List<double>();                 // This list will hold pi values for differen M values
            int K = 1;
            if (M == 8)
            {
                N = 16;
                K = 3;
                piList.Add(0.2148);
                piList.Add(0.3672);
                piList.Add(0.2305);
                piList.Add(0.1875);
            }

            if (M == 128)
            {
                N = 49;
                K = 5;
                piList.Add(0.1174);
                piList.Add(0.2430);
                piList.Add(0.2305);
                piList.Add(0.1752);
                piList.Add(0.1027);
                piList.Add(0.1124);
            }
            if (M == 10000)
            {
                K = 6;
                N = 75;
                piList.Add(0.0882);
                piList.Add(0.2092);
                piList.Add(0.2483);
                piList.Add(0.1933);
                piList.Add(0.1208);
                piList.Add(0.0675);
                piList.Add(0.0727);
            }


            double xSqrObs = 0;
            for (int i = 0; i <= K; i++)
            {
                xSqrObs = xSqrObs + (frequencyList[i] - N * piList[i]) * (frequencyList[i] - N * piList[i]) / (N * piList[i]);
            }

            Console.WriteLine("xSqrObs is   " + xSqrObs);

            // Let's start to calculate P-Value from gamma functions
            double pValue, pValue2; ;

            pValue = ClassGamma.Gamma((double)K / 2);
            pValue2 = ClassLowerGamma.incgamma((double)K / 2 , (double)xSqrObs / 2 );

            pValue = (float)pValue2 / (float)pValue;                            // it is lower incomplete gamma value but we need upper incomplete gamma value.So take complement
            pValue = 1 - pValue;                            // now we calculated P-Value




            return pValue;
        }
    }
}
