﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Longest_Run_in_a_Block_Test
{
    class ClassLowerGamma
    {
        public static double incgamma(double a, double x)
        {
            double sum = 0;
            double term = 1.0 / a;
            int n = 1;
            while (term != 0)
            {
                sum = sum + term;
                term = term * (x / (a + n));
                n++;
            }
            return Math.Pow(x, a) * Math.Exp(-1 * x) * sum;
        }
    }
}
