﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Longest_Run_in_a_Block_Test
{
    class ClassProcess
    {
        // This class 
        public static void MethodProcess(List<int> inputList, int N, int M)
        {
            int count = 0;                                          // This count will count the consequtive ones in a block 
            List<int> maxFrequencyList = new List<int>();           // this list will hold the max consecutive number of ones for each block 
            List<int> frequencyList = new List<int>();              // this list will hold all consequtive one frequencies for each block then record max to the maxFrequencyList


            for (int i = 0; i < N; i++)                             // This for calculate max run of ones for all blocks
            {
                for (int j = 0; j < M; j++)                         // This for loop calculates the all frequencies of ones in one . block. Then record them to the frequency list
                {
                    if (inputList[j + i * M] == 1)
                        count = count + 1;
                    else if ((count != 0) && (inputList[j + i * M] == 0))
                    {
                        frequencyList.Add(count);
                        count = 0;
                    }
                }
                if ((inputList[M + i * M - 1] == 1))      // it is the condition  that the last element of the each block is one (in this case according to the our code the lasr frequency of ones didnot recors, so we recording them)
                    frequencyList.Add(count);
                if (frequencyList.Count != 0)                           // This if else will record the maximum frequency of the 1 in on block to maxFrequencyList. As you now frequencyList hold all frequencies of 1 for one block only
                {
                    maxFrequencyList.Add(frequencyList.Max());
                    frequencyList.Clear();
                    count = 0;
                }
                else
                    maxFrequencyList.Add(0);                        // it is the condition if all values in a block 0 . Then them max frequency of 1  will be 0 
            }

            // Until now, we found all max frequencies of blocks and then record them maxFrequencyList

            List<int> frequencyListofMaxList = new List<int>();                             // The frequencies of elements in the max frequenciesList
            List<int> countList = new List<int>();
            frequencyListofMaxList = ClassProcess2.MethodProcess2(maxFrequencyList, M, countList);

            double pValue;
            pValue = ClassCalculateObs.MethodCalculateObs(frequencyListofMaxList, N, M);        // This class calculate X^2 Obs then P-Value. Return is P-VAlue. P-Value will help us to determine the sequence is random or not


            Console.WriteLine("P-Value is equal to   " + pValue);

            if (pValue >= 0.01)
            {
                Console.WriteLine("Since pValue is bigger than or equal to 0.01 , then the process is random");
            }
            else
                Console.WriteLine("Since pValue is smaller than 0.01 , then the process is not random");

            return;
        }
    }
}
