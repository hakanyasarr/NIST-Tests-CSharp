﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Variant_Test
{
    class ClassPValueCalculator
    {
        public static void MethodPValueCalculator(List<int> sortedList, List<int>valueList, int J)
        {

            List<double> listofPValues = new List<double>();
            double pValue;
            double sentValue;
            for ( int i = 0 ; i<sortedList.Count ; i++)
            {
                sentValue = Math.Abs(valueList[i] - J) / Math.Sqrt(2 * J * (4 * Math.Abs(sortedList[i] )- 2));
                listofPValues.Add(1 - ClassErrorFunction.Erf(sentValue));            
            }         
            for (int j = 0 ;j < listofPValues.Count ; j++)
            {
                Console.WriteLine(" P - Values is " + listofPValues[j]);
                if (listofPValues[j] < 0.01)
                    Console.WriteLine(" Since P-Value is small than 0.01 then sequence is not random");
                else
                    Console.WriteLine(" Since P-Value is bigger than or equal to 0.01 then sequence is random");

            }
            Console.WriteLine("For pValues which is bigger than 0.01 then sequence can accept random");

            return;
        }
    }
}
