﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Variant_Test
{
    class ClassProcess
    {
        public static void MethodProcess(List<int> sumList, int n)
        {
            sumList.Add(0);
            sumList.Reverse();
            sumList.Add(0);
            sumList.Reverse();
            int J = 0;                      // J is the total number of zeros in the sumList except first zero sumList[0]

            for (int i = 1; i < n + 2; i++)
            {
                if (sumList[i] == 0)
                    J = J + 1;
            }            
            List<int> sortedList = new List<int>();
            List<int> valueList = new List<int>();
            int frequency ;
            bool control;
            int a = sumList.Min();
            int b = sumList.Max();
            // it will show us there are how many same number like intensity
            for ( ; a<=b ; a++)
            {
                sortedList.Add(a);
                frequency = 0;
                for (;;)
                {                    
                    control = sumList.Remove(a);
                    if (control == true)
                        frequency = frequency + 1;
                    else
                    {
                        valueList.Add(frequency);
                        break;
                    }

                }

            }

            if (sortedList.Contains(0) == true)
            {
                int indexNo;
                indexNo = sortedList.IndexOf(0);
                sortedList.RemoveAt(indexNo);
                valueList.RemoveAt(indexNo);
            }
            ClassPValueCalculator.MethodPValueCalculator(sortedList, valueList,J);
            return;
        }
    }
}
