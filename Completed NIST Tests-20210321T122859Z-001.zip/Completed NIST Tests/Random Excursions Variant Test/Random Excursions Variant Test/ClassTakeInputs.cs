﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Variant_Test
{
    class ClassTakeInputs
    {
        public static void MethodTakeInputs()
        {
           
            string epsilonInput = "0110110101";         // input sequence that we want to test
            int n = epsilonInput.Length;                                          //length of the input
            List<int> sumList = new List<int>();
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                if (epsilonInput[i] == '1')
                    sum = sum + 1;
                if (epsilonInput[i] == '0')
                    sum = sum - 1;
                sumList.Add(sum);
            }
            ClassProcess.MethodProcess(sumList, n);

            return;
        }
    }
}
