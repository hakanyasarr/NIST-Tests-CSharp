﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_Excursions_Variant_Test
{
    /*
    The focus of this test is the total number of times that a particular state is visited (i.e., occurs) in a
cumulative sum random walk. The purpose of this test is to detect deviations from the expected number
of visits to various states in the random walk. This test is actually a series of eighteen tests (and
conclusions), one test and conclusion for each of the states: -9, -8, …, -1 and +1, +2, …, +9. 

        input : input sequence (string type)(epsilonInput) that we want to test

        output : P-Values (type double) that will help us to decide the sequence is random or not
    */
    class Program
    {            static void Main()
        {
                ClassTakeInputs.MethodTakeInputs();

                return;
        }
    }
}
