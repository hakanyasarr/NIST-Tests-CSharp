﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaurersUniversalStatisticalT
{
    class Program
    {
        static void Main()
        {
            /*
            The focus of this test is the number of bits between matching patterns (a measure that is related to the
length of a compressed sequence). The purpose of the test is to detect whether or not the sequence can be
significantly compressed without loss of information. A significantly compressible sequence is
considered to be non-random. 

            input : (3 inputs) . First input input seqeuce (named epsilonInput and type string) that we want to test
                    Secon input is L . The focus of this test is the number of bits between matching patterns (a measure that is related to the
                        length of a compressed sequence). The purpose of the test is to detect whether or not the sequence can be
                        significantly compressed without loss of information. A significantly compressible sequence is
                        considered to be non-random. 
                    Third input is Q. The number of blocks in the initialization sequence. 

            output : Output is P-Value that will help us to decide the sequence is random or not.
 

    */
            ClassTakeInput.MethodTakeInput();


            return;
        }
    }
}
