﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaurersUniversalStatisticalT
{
    class ClassTakeInput
    {
        public static void MethodTakeInput()
        {
            string epsiloninput = "01011010011101010111";           // input sequence that we want to test
            int n = epsiloninput.Length ;                                            // size of input sequence
            int L =2 ;                                              // the length of the each block
            int Q =4 ;                                              // number of block in initialization segment

            int K = n / L -Q  ;                                         // number of block in Test Segment

            List<int> inputList = new List<int>() ;                 // the input elements will store here
            
            for(int i = 0 ; i < n ; i++ )
            {
                if (epsiloninput[i] == '1')
                    inputList.Add(1);
                else if (epsiloninput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("wrong input data !! Input must be collection of ones and zeros ");
            }
            ClassProcess.MethodProcess(inputList, L, Q , n , K);


            return;
        }
    }
}
