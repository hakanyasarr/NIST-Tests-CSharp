﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryMatrixRankTest
{
    /*
    The focus of the test is the rank of disjoint sub-matrices of the entire sequence. The purpose of this test is
to check for linear dependence among fixed length substrings of the original sequence. 
    
        inputs : (3 inputs) . One is input sequence (epsilonInput)(string type).
                  Second input is M. M represent the number of rows in each matrix
                  Third input is N. N represent the number of column in each matrix

        output : (1 output). Output is P-Value of sequence that will help us to decide the sequence is random or not
    */ 
    class Program
    {
        static void Main()
        {
            ClassTakeandProcessInput.MethodTakeandProcessInput();
            return;
        }
    }
}
