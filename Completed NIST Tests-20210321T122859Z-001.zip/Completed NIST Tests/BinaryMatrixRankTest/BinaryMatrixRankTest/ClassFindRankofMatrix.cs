﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryMatrixRankTest
{
    class ClassFindRankofMatrix
    {

        static public List<int> MethodFindRankofMatrix (List<int> inputList, int N, int M, int Q )
        {
            List<List<float>> rowList = new List<List<float>>() ;                       // it is the list in a form rows. That means each row is an element of the rowList
     
            for (int i = 0 ; i < N * M ; i++ )                                      // This for loop will record all rows into the rowList                               
            {
                rowList.Add(new List<float>());
           
                for (int j = 0 ; j < Q ; j++)
                {
                    rowList[i].Add(inputList[i * Q + j]);
                }
            }

            // Now we have collection of all matrix in a rows form. Let's start compute rank of the each matrix
                        
            List<int> rankList = new List<int>();                       // The rankList will record ranks of each matrix
            int d = 0 ;                                                     // d will used any purpose when we need a vairable
            float e, f;                                                      // for any purpose
            for ( int a = 0 ; a < N ; a++ )             
            {
                for( int b = 0 ; b < Q ; b++ )
                {
                    for( int c = 0 ; c < M ; c++)
                    {
                        if (rowList[a * M + c][b] == 0)
                            continue;
                        d = a * M + c ;
                        c++;
                        for( ; c < M ; c++)
                        {
                            if (rowList[a * M + c][b] == 1)
                            {
                                for(int x = 0 ; x < Q ; x++)
                                {
                                    e = rowList[d][x] * (-1) + rowList[a * M + c][x];
                                    rowList[a * M + c].RemoveAt(x);
                                    rowList[a * M + c].Insert(x, e);
                                }
                                for(int y = 0 ; y < Q ; y++ )
                                {
                                    if(rowList[a * M + c ] [y] != 0)
                                    {
                                        e = rowList[a * M + c][y];
                                        for( ; y < Q ; y++)
                                        {
                                            f = rowList[a * M + c][y]  / e ;
                                            rowList[a * M + c].RemoveAt(y);
                                            rowList[a * M + c].Insert(y, f);

                                        }
                                    }
                                }

                            }
                        }

                    }
                    for(int z = 0 ; z < Q ; z++ )
                    {
                        if(rowList[d][z] == 1)
                        {
                            z++;
                            for( ; z < Q ; z++ )
                            {
                                rowList[d].RemoveAt(z);
                                rowList[d].Insert(z, 0);
                            }
                        }
                    }

                }

            }

            // Thanks God ! We obtaint row reduces echolon form but jut leading entries (in rowList). Note : It is enough to calculate rank of matrices
            // Lets calculate ranks of metrices
            int rankValues = 0;             // it is a count that will count the number of the leading entry number

            for(int  i = 0 ; i < N ; i++)
            {
                for(int j =0 ; j < M ; j++ )
                {
                    for(int k = 0 ; k < Q ; k++ )
                    {
                        if (rowList[i * M + j][k] == 1)
                            rankValues = rankValues + 1;
                    }
                }
                rankList.Add(rankValues);
                rankValues = 0;
            }

            return rankList;
        }
    }
}
