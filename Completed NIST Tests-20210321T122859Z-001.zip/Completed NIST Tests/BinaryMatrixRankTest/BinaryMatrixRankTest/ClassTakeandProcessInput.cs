﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryMatrixRankTest
{
    class ClassTakeandProcessInput
    {
        public static void MethodTakeandProcessInput()
        {         
            string epsilonInput = "01011001001010101101";                 // input sequence that we want to test         
            int M = 3 ;                                     // The number of row in each matrix
            int Q = 3;                                      // The number of column in each matrix

            int n = epsilonInput.Length;                     // the element number in input sequence (epsilonInput)
            int N = n / (M * Q);                               // Total matrix number
            List<int> inputList = new List<int>();          // this for convert strint to the integer list as 0 or 1 list

            for (int i = 0; i < n; i++)                         // This for loop transfer elements of input sequence from epsilonInput to inputList. Actually convert string to the integere values
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input !! Input sequence have to be collecton of ones and zeros");
            }

            List<int> rankList = new List<int>();                           // This List will record the ranks of each matrix
            rankList = ClassFindRankofMatrix.MethodFindRankofMatrix(inputList, N, M, Q);

            // Now we have rankList that hold ranks of the metrices . Let^s move
            int fullRankNumber = 0;                         // FM = the number of matrices with R = M (full rank)
            int fullRankMinusOneNumber = 0;                     //FM-1 = the number of matrices with R = M-1 (full rank - 1)
            int lowerRankNumber = 0;                            // N – FM	 - FM-1 = the number of matrices remaining

            for( int j = 0 ; j < rankList.Count ; j++)
            {
                if (rankList[j] == Q)
                    fullRankNumber = fullRankNumber + 1;
                else if (rankList[j] == Q - 1)
                    fullRankMinusOneNumber = fullRankMinusOneNumber + 1;
                else
                    lowerRankNumber = lowerRankNumber + 1; 
            }

            // Now we will calculate X^2 Obs.

            double xSqrObs = 0;
            xSqrObs = ((double)fullRankNumber - 0.2888 * (double)N) * ((double)fullRankNumber - 0.2888 * (double)N) / (0.2888 * (double)N) + xSqrObs;
            xSqrObs = ((double)fullRankMinusOneNumber - 0.5776 * (double)N) * ((double)fullRankMinusOneNumber - 0.5776 * (double)N) / (0.5776 * (double)N) + xSqrObs;
            xSqrObs = ((double)lowerRankNumber - 0.1336 * (double)N) * ((double)lowerRankNumber - 0.1336 * (double)N) / (0.1336 * (double)N) + xSqrObs;

            // The final step is calculate P-Value = e^(-xSqrObs / 2 )

            double pValue = Math.Pow(Math.E, (-1) * xSqrObs / 2);
  
            Console.WriteLine("P-Value is " + pValue);
            if (pValue < 0.01)
                Console.WriteLine("Since P-Value is smaller than 0.01 then the sequence is not random");
            else
                Console.WriteLine("Since P-Value is bigger than or equal to 0.01 then the sequence is random");


            return;
        }
    }
}
