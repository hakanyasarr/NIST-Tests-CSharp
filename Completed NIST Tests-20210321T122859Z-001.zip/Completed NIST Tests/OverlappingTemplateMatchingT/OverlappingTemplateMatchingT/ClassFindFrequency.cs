﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverlappingTemplateMatchingT
{
    class ClassFindFrequency
    {
        // This class will help us to find the frequency of the B sequence into all blocks in input sequence
        public static List<int> MethodPFindFrequency (List<int> inputList, int decimalValueB, int M, int N, int lengthB)
        {
            int count ;                              // This count will count the number of sequence B in the sequence inputList  
            int value;
            List<int> frequencyList = new List<int>();
            frequencyList.Add(0);
            frequencyList.Add(0);
            frequencyList.Add(0);
            frequencyList.Add(0);
            frequencyList.Add(0);
            frequencyList.Add(0);
            int change = 0;                 // We will use this variable to increase one element in frequencyList by one
            for (int i = 0 ; i < N ; i++ )
            {
                count = 0 ;
                for(int j = 0 ; j < M -lengthB+1 ; j++)
                {
                    value = 0;
                    for(int k =0 ; k < lengthB ; k++ )
                    {
                        value = value + (int)Math.Pow(2, (double)(lengthB - 1 - k)) * inputList[ i * M + j + k ];
                    }
                    if (value == decimalValueB)
                        count = count + 1 ;
                }
                change = frequencyList[count];
                frequencyList.RemoveAt(count);
                frequencyList.Insert(count, change+1) ;
            }

                return frequencyList;
        }
    }
}
