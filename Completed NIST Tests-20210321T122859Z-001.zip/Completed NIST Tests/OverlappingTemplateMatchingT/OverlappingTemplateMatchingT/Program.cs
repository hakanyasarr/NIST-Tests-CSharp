﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverlappingTemplateMatchingT
{
    class Program
    {
        /*
        The focus of the Overlapping Template Matching test is the number of occurrences of pre-specified target
strings. Both this test and the Non-overlapping Template Matching test of Section 2.7 use an m-bit
window to search for a specific m-bit pattern. As with the test in Section 2.7, if the pattern is not found,
the window slides one bit position. The difference between this test and the test in Section 2.7 is that
when the pattern is found, the window slides only one bit before resuming the search. 

            input : input sequence (string type) epsilonInput that we want to test
                    input B (string type). The m-bit template to be matched. 
                    input K (int type). The number of freedom.
                    imput M (int type) . The number of elements in every block
            output: P-Value that will help us to decide the input sequence is random or not

    */
        static void Main()
        {
            ClassTakeInputs.MethodTakeInputs();
            return;
        }
    }
}
