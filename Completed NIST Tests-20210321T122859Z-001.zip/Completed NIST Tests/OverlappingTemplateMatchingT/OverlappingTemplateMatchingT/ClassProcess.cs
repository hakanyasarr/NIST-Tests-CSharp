﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverlappingTemplateMatchingT
{
    class ClassProcess
    {
        public static void MethodProcess(List<int> inputList, int decimalValueB, int M , int N , int lengthB, int m ,int K )
        {
            List<int> frequencyList = new List<int>() ;             // THis list will store frequency of the B sequence in input sequence for every block
            frequencyList = ClassFindFrequency.MethodPFindFrequency(inputList, decimalValueB, M, N, lengthB);

            double lamda, yu;               //Compute values for λ and η that will be used to compute the theoretical probabilities πi 
            lamda = (double)(M - m + 1) / Math.Pow(2, m);
            yu = lamda / 2;

            List<double> preProportionList = new List<double>();
            if (K == 2)
            {
                preProportionList.Add(0.324652);
                preProportionList.Add(0.182617);
                preProportionList.Add(0.142670);
                preProportionList.Add(0.106645);
                preProportionList.Add(0.077147);
                preProportionList.Add(0.166269);

            }
            else
            {
                preProportionList.Add(0.364091);
                preProportionList.Add(0.185659);
                preProportionList.Add(0.139381);
                preProportionList.Add(0.100571);
                preProportionList.Add(0.070432);
                preProportionList.Add(0.139865);
            }


            double xSqrObs = 0;

            for (int a = 0 ; a<= 5 ; a++)
            {
                xSqrObs = xSqrObs + (frequencyList[a] - (double)N * preProportionList[a]) * (frequencyList[a] - (double)N * preProportionList[a]) / ((double)N * preProportionList[a]);
            }

            // Let's start to calculate P-Value from gamma functions
            double pValue, pValue2;
        
            pValue = ClassGamma.Gamma((double)5 / (double)2);
            pValue2 = ClassLowerGamma.incgamma((double)5 / (double) 2, (double)xSqrObs / 2);

            pValue = (float)pValue2 / (float)pValue;                            // it is lower incomplete gamma value but we need upper incomplete gamma value.So take complement
            pValue = 1 - pValue;                            // now we calculated P-Value



            Console.WriteLine("P-Value is equal to   " + pValue);

            if (pValue >= 0.01)
            {
                Console.WriteLine("Since pValue is bigger than or equal to 0.01 , then the process is random");
            }
            else
                Console.WriteLine("Since pValue is smaller than 0.01 , then the process is not random");



            return;
        }
    }
}
