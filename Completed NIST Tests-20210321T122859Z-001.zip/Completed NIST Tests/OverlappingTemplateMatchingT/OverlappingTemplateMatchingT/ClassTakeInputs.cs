﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverlappingTemplateMatchingT
{
    class ClassTakeInputs
    {
        public static void MethodTakeInputs()
        {
            string epsilonInput = "10111011110110110100011100101110111110000101101001";             // input sequence
            int n = epsilonInput.Length;                                 // The size of the input sequence
            int K = 2;                  // The number of degrees of freedom
            int M = 10;                     // The length in bits of a substring of ε to be tested. In other words, length of the each block
            int N = n/M;                  // The number of independent blocks of n

           string B = "11";            //The m-bit template to be matched
            int m = B.Length;                  //The length in bits of the template – in this case, the length of the run of ones. 


            List<int> inputList = new List<int>();
            for( int i = 0 ; i<n ; i++ )
            {
                if (epsilonInput[i] == '1')
                    inputList.Add(1);
                else if (epsilonInput[i] == '0')
                    inputList.Add(0);
                else
                    Console.WriteLine("Wrong input epsilonInput !! Input must be a collection of ones and zeros");
            }

            int count = 0;              // This count will count the number of B in a block
            int lengtB = B.Count();          // it is the leng of m bit template. It is also  equal to m
            int decimalValueB = 0;             // It represent the decimal equivalent of sequence B
            List<int> bValueList = new List<int>();                         // This list wil record the B sequence elements
            for (int k = 0; k < lengtB; k++)
            {
                if (B[k] == '1')
                    bValueList.Add(1);
                else if (B[k] == '0')
                    bValueList.Add(0);
                else
                    Console.WriteLine("Wrong input B sequence !! Input must be a collection of ones and zeros");
            }

           

            for( int j = 0 ; j<lengtB ; j++)                        // This for loop calculate decimal value of string B (B have ones and zeros only)
            {
                decimalValueB = decimalValueB + bValueList[j] *(int) Math.Pow(2, (double)(lengtB - 1 - j));
            }



            ClassProcess.MethodProcess(inputList, decimalValueB, M, N ,lengtB, m , K);





            return;
        }
    }
}
